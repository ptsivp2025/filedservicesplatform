'use client';
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { setSession } from '@/lib/auth';

import { User, JabatanType, JABATAN_CONFIG, ALL_MENU_KEYS, ALL_MENU_LABELS, ROLE_BADGE } from './shared';
import { ModalPortal, formatUsername } from '@/components/shared';

import { ambilProfil, Kartu, Baris } from './modal-bersama';
import { hasFullAccess } from '@/lib/constants';
import { bacaPengaturan } from '@/lib/notifikasi/pengaturan';

// UserProfileModal

interface UserProfileModalProps {
  currentUser: User;
  onClose: () => void;
}

export function UserProfileModal({ currentUser, onClose }: UserProfileModalProps) {
  const [userData, setUserData] = useState<User>(currentUser);
  const [editPhone, setEditPhone] = useState(false);
  const [phoneInput, setPhoneInput] = useState(currentUser.phone_number || '');
  const [editPassword, setEditPassword] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [cariIzin, setCariIzin] = useState('');
  /** Notifikasi Telegram pribadi - lihat blok "Hubungkan Telegram" di bawah. */
  const [telegramBot, setTelegramBot] = useState<{ status: 'memuat' | 'siap' | 'galat'; username?: string; alasan?: string }>({ status: 'memuat' });
  const [menghubungkan, setMenghubungkan] = useState(false);
  const [pesanTelegram, setPesanTelegram] = useState<{ tipe: 'ok' | 'gagal'; teks: string } | null>(null);
  /**
   * Kanal Telegram bisa dimatikan admin (Admin Panel → Integrations). Kalau
   * mati, TIDAK ADA gunanya menawarkan "hubungkan Telegram" ke siapa pun -
   * pesan memang tidak akan pernah terkirim ke kanal itu. null = belum
   * diketahui (jangan render dulu, supaya tidak sempat kelihatan lalu hilang).
   */
  const [telegramAktif, setTelegramAktif] = useState<boolean | null>(null);
  /** Auto-cek koneksi Telegram setelah bot dibuka - lihat mulaiAutoHubung(). */
  const [autoHubung, setAutoHubung] = useState<'diam' | 'menunggu' | 'gagal'>('diam');
  const autoHubungRef = useRef<{ interval?: ReturnType<typeof setInterval>; timeout?: ReturnType<typeof setTimeout> }>({});

  const notify = (type: 'success' | 'error', msg: string) => {
    setNotification({ type, msg });
    setTimeout(() => setNotification(null), 3500);
  };

  useEffect(() => {
    (async () => {
      const { data } = await ambilProfil(currentUser.id);
      if (data) { setUserData(data); setPhoneInput(data.phone_number || ''); }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch('/api/notifikasi/telegram', {
          method: 'POST', credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ aksi: 'bot_info' }),
        });
        const j = await r.json() as { ok?: boolean; alasan?: string; bot?: string };
        setTelegramBot(j?.ok && j.bot
          ? { status: 'siap', username: j.bot }
          : { status: 'galat', alasan: j?.alasan ?? 'Bot Telegram belum diatur admin.' });
      } catch {
        setTelegramBot({ status: 'galat', alasan: 'Tidak bisa menghubungi server.' });
      }
    })();
  }, []);

  // Kanal Telegram (Admin Panel → Integrations → Kanal & Event) - kalau admin
  // mematikannya, seluruh blok "Notifikasi Telegram" disembunyikan untuk
  // SEMUA akun (lihat pemakaian telegramAktif di JSX).
  useEffect(() => {
    (async () => {
      try {
        const p = await bacaPengaturan();
        setTelegramAktif(p.aktif.telegram);
      } catch { setTelegramAktif(false); }
    })();
  }, []);

  const hentikanAutoHubung = () => {
    if (autoHubungRef.current.interval) clearInterval(autoHubungRef.current.interval);
    if (autoHubungRef.current.timeout) clearTimeout(autoHubungRef.current.timeout);
    autoHubungRef.current = {};
  };
  useEffect(() => hentikanAutoHubung, []);

  const cekHubunganTelegramSekali = async (): Promise<boolean> => {
    try {
      const r = await fetch('/api/notifikasi/telegram', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aksi: 'hubungkan' }),
      });
      const j = await r.json() as { ok?: boolean };
      return !!j?.ok;
    } catch { return false; }
  };

  /**
   * Membuka bot Telegram dengan payload = id akun sendiri, LALU otomatis
   * mengecek berkala (tiap 4 detik, sampai 5 menit) apakah orangnya sudah
   * menekan Start di sana - tidak ada lagi tombol konfirmasi manual. Kalau
   * sampai 5 menit belum terbaca, berhenti dan statusnya kembali "Belum
   * Terhubung" (orangnya tinggal tekan tombolnya lagi untuk mencoba ulang).
   *
   * Lihat catatan panjang di app/api/notifikasi/telegram/route.ts tentang
   * kenapa payload start=<id akun sendiri> ini aman dipakai siapa saja.
   */
  const mulaiAutoHubung = () => {
    if (telegramBot.status !== 'siap' || !telegramBot.username) return;
    window.open(`https://t.me/${telegramBot.username}?start=${currentUser.id}`, '_blank', 'noopener,noreferrer');

    hentikanAutoHubung();
    setPesanTelegram(null);
    setAutoHubung('menunggu');

    const cekSekali = async () => {
      const berhasil = await cekHubunganTelegramSekali();
      if (!berhasil) return;
      hentikanAutoHubung();
      setAutoHubung('diam');
      setPesanTelegram({ tipe: 'ok', teks: 'Telegram terhubung! Notifikasi akan masuk ke chat itu.' });
      const { data } = await ambilProfil(currentUser.id);
      if (data) { setUserData(data); setSession(data); }
    };
    cekSekali(); // langsung cek sekali, jangan tunggu interval pertama
    autoHubungRef.current.interval = setInterval(cekSekali, 4000);
    autoHubungRef.current.timeout = setTimeout(() => {
      hentikanAutoHubung();
      setAutoHubung('gagal');
    }, 5 * 60 * 1000);
  };

  const putuskanTelegram = async () => {
    setMenghubungkan(true);
    setPesanTelegram(null);
    try {
      const r = await fetch('/api/notifikasi/telegram', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aksi: 'putuskan' }),
      });
      const j = await r.json() as { ok?: boolean; alasan?: string };
      if (j?.ok) {
        setPesanTelegram(null);
        const { data } = await ambilProfil(currentUser.id);
        if (data) { setUserData(data); setSession(data); }
      } else {
        setPesanTelegram({ tipe: 'gagal', teks: j?.alasan ?? 'Gagal memutuskan.' });
      }
    } catch {
      setPesanTelegram({ tipe: 'gagal', teks: 'Tidak bisa menghubungi server.' });
    }
    setMenghubungkan(false);
  };

  const handleSavePhone = async () => {
    setSaving(true);
    const { error } = await supabase.from('users').update({ phone_number: phoneInput.trim() }).eq('id', currentUser.id);
    if (error) { notify('error', 'Gagal menyimpan nomor telepon.'); }
    else {
      notify('success', 'Nomor WhatsApp berhasil diperbarui!');
      setEditPhone(false);
      const { data } = await ambilProfil(currentUser.id);
      if (data) { setUserData(data); setSession(data); }
    }
    setSaving(false);
  };

  const getPasswordStrength = (pwd: string): { score: number; label: string; color: string } => {
    if (!pwd) return { score: 0, label: '', color: '' };
    let score = 0;
    if (pwd.length >= 8) score++;
    if (pwd.length >= 12) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^A-Za-z0-9]/.test(pwd)) score++;
    if (score <= 1) return { score, label: 'Lemah', color: 'bg-red-400' };
    if (score <= 2) return { score, label: 'Cukup', color: 'bg-amber-400' };
    if (score <= 3) return { score, label: 'Baik', color: 'bg-yellow-400' };
    return { score, label: 'Kuat', color: 'bg-emerald-500' };
  };

  const handleSavePassword = async () => {
    if (!passwordInput || passwordInput.length < 8) { notify('error', 'Password minimal 8 karakter.'); return; }
    if (!/[A-Z]/.test(passwordInput)) { notify('error', 'Password harus mengandung minimal 1 huruf kapital.'); return; }
    if (!/[0-9]/.test(passwordInput)) { notify('error', 'Password harus mengandung minimal 1 angka.'); return; }
    if (passwordInput !== confirmPassword) { notify('error', 'Konfirmasi password tidak cocok.'); return; }
    setSaving(true);
    const res = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: currentUser.id, newPassword: passwordInput }),
    });
    const result = await res.json();
    if (!res.ok) { notify('error', result.error || 'Gagal mengubah password.'); }
    else { notify('success', 'Password berhasil diubah!'); setEditPassword(false); setPasswordInput(''); setConfirmPassword(''); }
    setSaving(false);
  };

  const roleClass = ROLE_BADGE[userData.role?.toLowerCase()] || 'bg-slate-100 text-slate-700 border-slate-200';
  const initials = userData.full_name?.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2);
  const jabatanCfg = userData.jabatan ? JABATAN_CONFIG[userData.jabatan as JabatanType] : null;

  // Nilai turunan untuk tampilan
  const salam = (() => {
    const j = new Date().getHours();
    if (j < 11) return 'Selamat Pagi';
    if (j < 15) return 'Selamat Siang';
    if (j < 19) return 'Selamat Sore';
    return 'Selamat Malam';
  })();

  // Admin, superadmin, dan pemegang Full Access melewati allowed_menus
  // sepenuhnya (lihat saringan menu di dashboard/page.tsx), jadi daftarnya
  // dianggap penuh - kalau tidak, profil mereka justru terbaca paling sedikit
  // aksesnya, kebalikan dari kenyataannya.
  const menuAktif = hasFullAccess(userData)
    ? ALL_MENU_KEYS
    : (userData.allowed_menus ?? []);

  const menuTersaring = menuAktif.filter(k => {
    const q = cariIzin.trim().toLowerCase();
    if (!q) return true;
    return `${k} ${ALL_MENU_LABELS[k]?.label ?? ''}`.toLowerCase().includes(q);
  });

  const bergabung = (userData as { created_at?: string }).created_at
    ? new Date((userData as { created_at?: string }).created_at as string)
        .toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })
    : '—';

  return (
  <ModalPortal>
    <div role="dialog" aria-modal="true" className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/60 backdrop-blur-sm p-3 sm:p-4">
      <div className="bg-slate-50 rounded-2xl shadow-2xl w-full max-w-5xl h-full max-h-full flex flex-col overflow-hidden border border-slate-200">

        {/* ── HERO ──
            Menyapa lalu langsung menyebut identitas, bukan judul generik
            "User Profile". Judul semacam itu hanya mengulang apa yang sudah
            jelas dari cara halamannya dibuka — ruangnya lebih berguna dipakai
            menampilkan siapa pemilik akun ini. */}
        <div className="flex-shrink-0 px-6 py-5 relative overflow-hidden"
          style={{ background: 'linear-gradient(120deg,#be123c,#9f1239 55%,#881337)' }}>
          <button aria-label="Tutup" onClick={onClose}
            className="absolute top-4 right-4 bg-white/15 hover:bg-white/25 text-white p-2 rounded-lg transition-all z-10">
            <svg aria-hidden="true" focusable="false" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
          <div className="flex flex-wrap items-end justify-between gap-4 pr-10">
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-rose-200/90 mb-1.5">
                {salam} · <span className="text-white/70 normal-case tracking-normal font-medium">{formatUsername(userData.username)}</span>
              </p>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-tight truncate">
                {userData.full_name}
              </h2>
              <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                {jabatanCfg && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold bg-white/15 text-white backdrop-blur">
                    {jabatanCfg.icon} {userData.jabatan}
                  </span>
                )}
                {jabatanCfg && userData.team_type && (
                  <span className="text-white/40 text-xs">›</span>
                )}
                {userData.team_type && (
                  <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-bold bg-white/15 text-white backdrop-blur">
                    {userData.team_type}
                  </span>
                )}
              </div>
            </div>
            <div className="flex gap-2.5 flex-shrink-0">
              <div className="rounded-xl px-4 py-2.5 text-center min-w-[76px]" style={{ background: 'rgba(0,0,0,0.22)' }}>
                <p className="text-2xl font-black text-white leading-none">{menuAktif.length}</p>
                <p className="text-[9px] font-bold uppercase tracking-widest text-rose-200/80 mt-1">Modul</p>
              </div>
              <div className="rounded-xl px-4 py-2.5 text-center min-w-[76px]" style={{ background: 'rgba(250,204,21,0.9)' }}>
                <p className="text-sm font-black text-amber-900 leading-none pt-1.5 truncate">{userData.role}</p>
                <p className="text-[9px] font-bold uppercase tracking-widest text-amber-900/70 mt-1.5">Peran</p>
              </div>
            </div>
          </div>
        </div>

        {notification && (
          <div className={`mx-5 mt-4 px-4 py-3 rounded-lg text-sm font-semibold flex items-center gap-2 flex-shrink-0 ${notification.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
            {notification.type === 'success' ? '✅' : '❌'} {notification.msg}
          </div>
        )}

        <div className="flex-1 min-h-0 overflow-y-auto p-5">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

            {/* ══ KIRI ══ */}
            <div className="lg:col-span-2 space-y-4">

              {/*
                Notifikasi Telegram sengaja diletakkan PALING ATAS, sebelum
                Informasi Pribadi - supaya langsung terlihat tanpa scroll ke
                tengah. Orang awam yang belum terhubung jarang scroll mencari
                sendiri; kartu ini justru satu-satunya yang butuh tindakan
                dari pemilik akun begitu profil dibuka.
              */}
              {telegramAktif && (
              <Kartu icon="✈️" judul="Notifikasi Telegram">
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">Status</span>
                    {userData.telegram_chat_id ? (
                      <span className="inline-flex items-center gap-1.5 text-emerald-600 font-bold text-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Terhubung
                      </span>
                    ) : autoHubung === 'menunggu' ? (
                      <span className="inline-flex items-center gap-1.5 text-sky-600 font-bold text-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-sky-500 animate-pulse" /> Menunggu konfirmasi…
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-amber-600 font-bold text-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Belum Terhubung
                      </span>
                    )}
                  </div>

                  {userData.telegram_chat_id ? (
                    <>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        Notifikasi assign & jadwal akan ikut masuk ke Telegram, berdampingan dengan WhatsApp.
                      </p>
                      <button onClick={putuskanTelegram} disabled={menghubungkan}
                        className="w-full py-2 rounded-xl border border-red-200 bg-white text-xs font-bold text-red-600 hover:bg-red-50 transition-all disabled:opacity-40">
                        {menghubungkan ? 'Memutuskan…' : 'Putuskan Telegram'}
                      </button>
                    </>
                  ) : telegramBot.status === 'galat' ? (
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Belum bisa dipakai - {telegramBot.alasan}
                    </p>
                  ) : (
                    <>
                      <ol className="text-[11px] text-slate-500 leading-relaxed space-y-1 list-decimal list-inside">
                        <li>Tekan <b>Buka Bot &amp; Kirim Start</b> - Telegram terbuka, tekan <b>Start</b> di sana.</li>
                        <li>Kembali ke sini - koneksi terdeteksi otomatis, tidak perlu menekan apa pun lagi.</li>
                      </ol>
                      <button onClick={mulaiAutoHubung} disabled={autoHubung === 'menunggu' || telegramBot.status !== 'siap'}
                        className="w-full py-2.5 rounded-xl text-white text-sm font-bold transition-all disabled:opacity-40 flex items-center justify-center gap-2"
                        style={{ background: '#0088cc' }}>
                        {telegramBot.status === 'memuat' ? 'Memuat…' : autoHubung === 'menunggu' ? 'Menunggu konfirmasi…' : '➤ Buka Bot & Kirim Start'}
                      </button>
                      {autoHubung === 'menunggu' && (
                        <p className="text-[11px] text-sky-600 leading-relaxed">
                          ⏳ Mengecek otomatis tiap beberapa detik, maks. 5 menit setelah Anda menekan Start di Telegram.
                        </p>
                      )}
                      {autoHubung === 'gagal' && (
                        <p className="text-[11px] text-red-600 leading-relaxed">
                          ⚠️ Belum terhubung. Pastikan sudah menekan Start di bot, lalu tekan tombolnya lagi.
                        </p>
                      )}
                    </>
                  )}

                  {pesanTelegram && (
                    <div className={`rounded-lg px-2.5 py-2 text-[11px] font-semibold ${pesanTelegram.tipe === 'ok' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-600 border border-red-200'}`}>
                      {pesanTelegram.tipe === 'ok' ? '✅' : '⚠️'} {pesanTelegram.teks}
                    </div>
                  )}
                </div>
              </Kartu>
              )}

              <Kartu icon="👤" judul="Informasi Pribadi & Kontak">
                <div className="divide-y divide-slate-100">
                  <Baris icon="#"  label="Username / NIK"  value={formatUsername(userData.username)} />
                  <Baris icon="👤" label="Nama Lengkap"    value={userData.full_name} />
                  <Baris icon="📱" label="No. Telepon / WA">
                    {editPhone ? (
                      <div className="flex items-center gap-2">
                        <input value={phoneInput} onChange={e => setPhoneInput(e.target.value)}
                          placeholder="08xxxxxxxxxx"
                          className="w-40 rounded-lg border border-slate-300 px-2.5 py-1 text-sm outline-none focus:ring-2 focus:ring-rose-200" />
                        <button onClick={handleSavePhone} disabled={saving}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold disabled:opacity-40">Simpan</button>
                        <button onClick={() => { setEditPhone(false); setPhoneInput(userData.phone_number || ''); }}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-500 text-xs font-bold">Batal</button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className={userData.phone_number ? 'text-slate-800 font-semibold text-sm' : 'text-slate-300 text-sm'}>
                          {userData.phone_number || 'Belum diisi'}
                        </span>
                        <button onClick={() => setEditPhone(true)}
                          className="text-[11px] text-rose-600 font-bold hover:underline">Ubah</button>
                      </div>
                    )}
                  </Baris>
                  {/* team_type bisa dipaksa jadi label status bypass ('Learning Center -
                      Bypass Event') oleh app/api/auth/register/route.ts supaya gampang
                      difilter admin. Itu benar di kolom database, tapi salah kalau ikut
                      dipakai buat menutupi divisi ASLI yang dipilih user (sales_division)
                      di sini - makanya field ini dikecualikan khusus untuk label bypass. */}
                  <Baris icon="🏢" label="Divisi / Team"
                    value={(userData.team_type !== 'Learning Center - Bypass Event' && userData.team_type) || '—'} />
                  <Baris icon="⭐" label="Jabatan"       value={userData.jabatan || '—'} />
                  <Baris icon="📅" label="Bergabung Sejak" value={bergabung} />
                  <Baris icon="🔑" label="Status Akun">
                    <span className="inline-flex items-center gap-1.5 text-emerald-600 font-bold text-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Aktif
                    </span>
                  </Baris>
                </div>
              </Kartu>

              <Kartu icon="🛡️" judul="Keamanan & Sandi">
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">Sesi Saat Ini</span>
                    <span className="inline-flex items-center gap-1.5 text-emerald-600 font-bold text-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Online &amp; Terotentikasi
                    </span>
                  </div>
                  {editPassword ? (
                    <div className="space-y-2 pt-1">
                      <input type="password" value={passwordInput} onChange={e => setPasswordInput(e.target.value)}
                        placeholder="Password baru (min. 8 karakter, 1 kapital, 1 angka)"
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-200" />
                      {passwordInput && (() => {
                        const { score, label, color } = getPasswordStrength(passwordInput);
                        return (
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                              <div className={`h-full ${color} transition-all`} style={{ width: `${(score / 5) * 100}%` }} />
                            </div>
                            <span className="text-[11px] font-bold text-slate-500">{label}</span>
                          </div>
                        );
                      })()}
                      <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)}
                        placeholder="Ulangi password baru"
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-200" />
                      {confirmPassword && passwordInput !== confirmPassword && (
                        <p className="text-[11px] text-red-500 font-semibold">Password tidak cocok</p>
                      )}
                      <div className="flex gap-2">
                        <button onClick={handleSavePassword} disabled={saving}
                          className="px-3 py-1.5 bg-rose-600 text-white text-xs font-bold rounded-lg disabled:opacity-40">Simpan Password</button>
                        <button onClick={() => { setEditPassword(false); setPasswordInput(''); setConfirmPassword(''); }}
                          className="px-3 py-1.5 bg-slate-100 text-slate-500 text-xs font-bold rounded-lg">Batal</button>
                      </div>
                    </div>
                  ) : (
                    <button onClick={() => setEditPassword(true)}
                      className="w-full py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold text-slate-600 hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
                      🔑 Ubah Password
                    </button>
                  )}
                </div>
              </Kartu>
            </div>

            {/* ══ KANAN ══ */}
            <div className="space-y-4">
              <Kartu icon="🎭" judul="Peran Pengguna" hitung="1 Role">
                <div className="p-4 space-y-3">
                  <span className={`inline-flex px-3 py-1.5 rounded-lg text-xs font-bold border ${roleClass}`}>
                    {userData.role}
                  </span>
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1.5">Level Akses</p>
                    <span className={`inline-flex px-3 py-1.5 rounded-lg text-xs font-bold border ${
                      (userData as { access_level?: string }).access_level === 'full'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-slate-100 text-slate-500 border-slate-200'
                    }`}>
                      {(userData as { access_level?: string }).access_level === 'full' ? '🔓 Full Access' : '🔒 Guest'}
                    </span>
                  </div>
                </div>
              </Kartu>

              <Kartu icon="🔐" judul="Hak Akses Modul" hitung={String(menuAktif.length)}>
                <div className="p-4 space-y-2.5">
                  <input aria-label="Cari modul..." value={cariIzin} onChange={e => setCariIzin(e.target.value)}
                    placeholder="🔍 Cari modul..."
                    className="w-full rounded-lg border border-slate-200 px-3 py-1.5 text-xs outline-none focus:ring-2 focus:ring-rose-200" />
                  {/* TANPA max-h: halaman ini sudah menggulir sebagai satu blok
                      (bungkusnya flex-1 overflow-y-auto di induk - lihat
                      className pembungkus modal). Kotak setinggi 256px yang
                      menggulir sendiri DI DALAM halaman yang sudah menggulir
                      menyembunyikan chip tanpa penanda apa pun - diuji dengan
                      14 modul aktif: badge menunjukkan "14" tapi hanya 9 chip
                      yang terlihat, 128px sisanya tersembunyi begitu saja. */}
                  <div className="flex flex-wrap gap-1.5">
                    {menuTersaring.length === 0 ? (
                      <p className="text-xs text-slate-400 py-2">Tidak ada modul yang cocok.</p>
                    ) : menuTersaring.map(k => {
                      const cfg = ALL_MENU_LABELS[k];
                      return (
                        <span key={k}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                          {cfg?.icon} {cfg?.label ?? k}
                        </span>
                      );
                    })}
                  </div>
                  <p className="text-[10px] text-slate-400 leading-relaxed pt-1">
                    Daftar ini ditentukan admin lewat Admin Panel. Untuk menambah akses modul,
                    hubungi admin.
                  </p>
                </div>
              </Kartu>
            </div>
          </div>
        </div>
      </div>
    </div>
  </ModalPortal>
  );
}
