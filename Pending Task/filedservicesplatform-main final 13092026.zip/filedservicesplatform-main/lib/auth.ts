import { setDbToken, dbTokenExpiryMs, refreshDbToken } from './supabase';
/**
 * lib/auth.ts - Helper auth terpusat
 *
 * Arsitektur session (v2):
 * - Auth TOKEN   httpOnly cookie (diset oleh /api/auth/login, tidak bisa dibaca JS)
 * - User PROFILE  sessionStorage (bisa dibaca JS, cleared on tab close, bukan localStorage)
 *
 * Keuntungan vs localStorage:
 * - Token tidak bisa dicuri via XSS (httpOnly cookie)
 * - Profile hilang saat browser/tab ditutup (lebih singkat exposure)
 * - Cookie expired = session otomatis invalid di server
 */

import { SESSION_DURATION_MS } from './constants';

const SS_USER = 'ivp_user';
const SS_TIME = 'ivp_login_time';

/**
 * Set session setelah login berhasil.
 * Token sudah diset sebagai httpOnly cookie oleh API route /api/auth/login.
 * Di sini kita hanya simpan profile user di sessionStorage untuk akses sync.
 */
export function setSession(userData: object): void {
  const now = Date.now();
  sessionStorage.setItem(SS_USER, JSON.stringify(userData));
  sessionStorage.setItem(SS_TIME, String(now));
}

/**
 * Hapus session (logout).
 * Hapus profile dari sessionStorage + invalidate httpOnly cookie via API.
 */
export function clearSession(): void {
  sessionStorage.removeItem(SS_USER);
  sessionStorage.removeItem(SS_TIME);
  // fs_selected_project_id (dibaca sinkron oleh ControlRoomWidget,
  // ExecutionWidget, dashboard/page.tsx, field-service/page.tsx sebagai nilai
  // AWAL sebelum project list sempat dimuat) HARUS ikut dibuang di sini juga -
  // ditemukan lewat laporan user: buka Dashboard, dropdown "Select project"
  // masih kosong, tapi tabel/angka ringkasan SUDAH tampil. Sebabnya: kunci
  // ini tidak pernah dibersihkan saat logout, jadi begitu user lain login di
  // tab yang sama, widget membaca project id milik user SEBELUMNYA dari
  // sessionStorage dan langsung memuat datanya sebelum user baru sempat
  // memilih project sendiri - risiko nyata kalau user baru itu tidak
  // di-assign ke project yang sama.
  sessionStorage.removeItem('fs_selected_project_id');
  // Fire-and-forget: invalidate cookie di server
  // Token PostgREST ikut dibuang; kalau tertinggal, tab yang sama masih
  // memegang identitas user yang baru saja keluar.
  setDbToken(null);
  fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
}

/**
 * Baca session dari sessionStorage (sync, fast).
 * Mengembalikan null jika tidak ada atau sudah expired.
 * Untuk verifikasi dari cookie: gunakan verifySessionFromCookie().
 */
export function getSession<T = Record<string, unknown>>(): T | null {
  try {
    const saved = sessionStorage.getItem(SS_USER);
    const savedTime = sessionStorage.getItem(SS_TIME);
    if (!saved) return null;
    if (savedTime) {
      const elapsed = Date.now() - parseInt(savedTime, 10);
      if (elapsed > SESSION_DURATION_MS) {
        clearSession();
        return null;
      }
    }
    return JSON.parse(saved) as T;
  } catch {
    return null;
  }
}

/**
 * Verifikasi session dari httpOnly cookie (async).
 * Digunakan saat sessionStorage kosong (refresh halaman).
 * Mengembalikan user data jika cookie valid, null jika tidak.
 */
export async function verifySessionFromCookie<T = Record<string, unknown>>(): Promise<T | null> {
  try {
    const res = await fetch('/api/auth/session', { credentials: 'include' });
    if (!res.ok) return null;
    const { user, db_token } = await res.json();
    if (user) {
      // Re-populate sessionStorage dari cookie yang valid
      setSession(user);
      // Pasang ulang token PostgREST - tanpa ini, query setelah refresh
      // halaman berangkat tanpa identitas.
      setDbToken(db_token ?? null);
    }
    return user ?? null;
  } catch {
    return null;
  }
}

/**
 * Cek session dan redirect ke dashboard jika expired.
 * Mengembalikan true jika session masih valid.
 */
export function checkSessionOrRedirect(): boolean {
  const user = getSession();
  if (!user) {
    const target = window.top !== window ? window.top : window;
    if (target) target.location.href = '/dashboard';
    return false;
  }
  return true;
}

/**
 * Setup interval cek session (tiap 60 detik).
 * Kembalikan cleanup function untuk dipakai di useEffect return.
 */
/**
 * Perbarui token PostgREST bila sudah dekat kedaluwarsa.
 *
 * Token dan sesi browser sama-sama berumur 6 jam tapi diperpanjang oleh hal
 * berbeda: setSession() mengulang hitungan mundur sesi dari nol tanpa ikut
 * menerbitkan token baru. Tanpa pemantau ini, sesi bisa terlihat segar
 * sementara PostgREST menolak setiap query dengan galat JWT, dan dari sisi
 * user tidak ada tanda apa pun bahwa sesinya bermasalah.
 */
export async function refreshDbTokenIfNeeded(ambangMenit = 30): Promise<void> {
  const exp = dbTokenExpiryMs();
  // Tidak ada token: biarkan - permintaan berjalan memakai anon key seperti
  // sebelum fitur token ada, dan verifySessionFromCookie yang akan memasangnya.
  if (exp === null) return;
  if (exp - Date.now() > ambangMenit * 60_000) return;
  await refreshDbToken();
}

export function startSessionWatcher(): () => void {
  // Sekali di awal: menolong tab yang sudah lama terbuka dengan token basi.
  void refreshDbTokenIfNeeded();
  const interval = setInterval(() => {
    if (!checkSessionOrRedirect()) return;
    void refreshDbTokenIfNeeded();
  }, 60_000);
  return () => clearInterval(interval);
}
